public class Loader {
    public static void main(String[] args) {

        String array[] = {"Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Violet"};

        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }

            System.out.println();

            for (int j = array.length - 1; j >= 0; j--) {
                System.out.print(array[j] + " ");
            }
        }
    }



