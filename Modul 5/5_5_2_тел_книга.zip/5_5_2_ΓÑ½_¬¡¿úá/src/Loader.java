import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.TreeMap;

public class Loader {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        TreeMap<String, String> abonent = new TreeMap<>();
        for (; ; ) {
            System.out.println("Пожалуйста введите номер телефона или имя аббонента: ");
            String number = reader.readLine().trim();
            String name = abonent.get(number);

            if (number.equals("List")) {
                for (String name1 : abonent.keySet()) {
                    System.out.println("аббонент: " + abonent.get(name1) + " номер: " + name1); // не выводиттся имя
                }
            }

//            if (abonent.containsKey(number)) {
//                System.out.println("Имя аббонента: " + name + " Номер " + number);}

            if (number.matches("(\\+)?\\d*")) {

                if (number != null){
                    System.out.println("Имя аббонента: " + name + " Номер " + number);

                } else {
                    System.out.println("Аббонента в тел книги нет, введите имя: ");
                    name = reader.readLine().trim();
                    if (name.isEmpty()) {
                        System.out.println("Не правильно указано имя");
                    } else {
                        abonent.put(number, name);
                        System.out.println("Аббонент сохранен");
                    }
                }
            }

            if (number.matches("( \\D* )")) {
//                if (abonent.containsValue(name)){
//                    System.out.println("Имя аббонента: " + name + " Номер " + number);
//                }
                System.out.println(number);}
                if (name != null) {
                    System.out.println("Имя аббонента: " + name + " Номер " + number);
                } else {
                    System.out.println("Номера в тел книги нет, введите номер: ");
                    number = reader.readLine().trim();
                    if (number.isEmpty()) {
                        System.out.println("Не правильно указан номер");
                    } else {
                        abonent.put(number, name);
                        System.out.println("Номер сохранен");

                    }
//            }
//            else {
//                String name2 = abonent.get(number);
//                if (name2 == null) {
//                    System.out.println("Пожалуйста введите имя аббонента: ");
//                    name2 = reader.readLine().trim();
//                }
//
//
//                abonent.put(number, name2);
//
//
//            }

                    // необходима проверка номер это или имя


//                if (abonentNum.containsKey(number)) {
//
//                    System.out.println("номер телефона: " + number + " имя абонента: " + abonentNum.get(number));
//                }
//                if (abonentNum.containsValue(number)){
//
//
//
//                } else {
//

                }
            }

        }
    }




