public class Loader {
    public static void main(String[] args) {

        double a = 24.0 * 0.1;
        System.out.println( " a = " + a);
    }
}
