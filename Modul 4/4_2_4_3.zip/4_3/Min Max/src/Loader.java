public class Loader {
    public static void main(String[] args) {

        System.out.println("max short " + Short.MAX_VALUE);
        System.out.println("min short " + Short.MIN_VALUE);
        System.out.println("max long " + Long.MAX_VALUE);
        System.out.println("min long " + Long.MIN_VALUE);
        System.out.println("max float " + Float.MAX_VALUE);
        System.out.println("min float " + Float.MIN_VALUE);
        System.out.println("max double " + Double.MAX_VALUE);
        System.out.println("min double " + Double.MIN_VALUE);
    }
}
