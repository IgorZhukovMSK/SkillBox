public class Del {
    public static void main(String[] args) {

        int i = 1666/100;
        System.out.println( "Итого " + i);
    }

}
